from .spa_scraper_pyo3 import *

__doc__ = spa_scraper_pyo3.__doc__
if hasattr(spa_scraper_pyo3, "__all__"):
    __all__ = spa_scraper_pyo3.__all__